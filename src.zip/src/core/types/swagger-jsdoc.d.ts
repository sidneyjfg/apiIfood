declare module 'swagger-jsdoc' {
  const swaggerJSDoc: (options: any) => any;
  export default swaggerJSDoc;
}
