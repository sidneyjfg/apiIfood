import { Router } from 'express';
// import { startPicking } from './controllers/pickingController';

const router = Router();

// Exemplo:
// router.post('/start', startPicking);

export default router;
