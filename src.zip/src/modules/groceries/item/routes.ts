import { Router } from 'express';
// import { listGroceriesItems } from './controllers/itemController';

const router = Router();

// Exemplo:
// router.get('/', listGroceriesItems);

export default router;
