import { Router } from 'express';
// import { pollEvents } from './controllers/eventsController';

const router = Router();

// Exemplo de polling (implementar controller quando precisar):
// router.get('/poll', pollEvents);

export default router;
